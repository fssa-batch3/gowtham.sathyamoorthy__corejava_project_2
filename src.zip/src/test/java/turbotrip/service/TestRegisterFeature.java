package turbotrip.service;
import static org.junit.jupiter.api.Assertions.*;
import java.sql.Connection;
import java.sql.SQLException;
import org.junit.jupiter.api.Test;
import turbotrip.model.User;
import turbotrip.service.UserService;
import turbotrip.service.exception.ServiceException;
import turbotrip.validation.exception.InvalidUserException;


public class TestRegisterFeature{
	
	//@Test 

//	public void testRegistrationSuccess() {
//		UserService userService = new UserService();
//		User user = new User("navee.krish1705@gmail.com","navee","Gowthi@123");
//		try {
//			assertTrue(userService.registerUser(user));
//		} catch (ServiceException e) {
//			e.printStackTrace();
//			fail();
//		}
//	}
//	
	
@Test

	public void testUserNull() {
		UserService userService = new UserService();
		User user = null;
		try {
			assertFalse(userService.registerUser(user));
		} catch ( ServiceException e) {
			e.printStackTrace();
		}
		
	}
}